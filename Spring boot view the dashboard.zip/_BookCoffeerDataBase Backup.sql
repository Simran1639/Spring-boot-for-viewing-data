-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: data
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `data`
--

DROP TABLE IF EXISTS `data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `data` (
  `end_year` int NOT NULL,
  `added` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `citylat` varchar(255) DEFAULT NULL,
  `citylng` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `impact` int NOT NULL,
  `insight` varchar(255) DEFAULT NULL,
  `intensity` int NOT NULL,
  `likelihood` int NOT NULL,
  `pestle` varchar(255) DEFAULT NULL,
  `published` varchar(255) DEFAULT NULL,
  `region` varchar(255) DEFAULT NULL,
  `relevance` int NOT NULL,
  `sector` varchar(255) DEFAULT NULL,
  `source` varchar(255) DEFAULT NULL,
  `start_year` int NOT NULL,
  `swot` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `topic` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`end_year`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data`
--

LOCK TABLES `data` WRITE;
/*!40000 ALTER TABLE `data` DISABLE KEYS */;
INSERT INTO `data` VALUES (2018,'June, 26 2018 07:28:39','','','','',0,'What\'s next for Health IT - Trends for 2018',12,4,'Technological','June, 26 2018 00:00:00','',3,'Information Technology','infosysblogs',2017,'','Adoption of AI diagnostics is expected to further accelerate through 2017-18.','artificial intelligence','http://www.infosysblogs.com/healthcare/2017/06/whats_next_for_health_it_-_tre.html'),(2020,'June, 26 2018 05:53:45','','','','',3,'The 8 Healthcare Trends that will impact your sales in 2018',16,4,'Healthcare','June, 26 2018 00:00:00','',4,'','',2010,'','The Specialty Pharma market was $274 b in 2010 and will be $483 b in 2020.','pharmaceutical','http://www.jhconline.com/the-8-healthcare-trends-that-will-impact-your-sales-in-2018.html'),(2024,'June, 26 2018 03:53:23','','','','',0,'Market share of top 20 companies for orphan drugs worldwide 2017 and 2024',20,4,'Healthcare','June, 26 2018 00:00:00','World',5,'Pharmaceuticals','Statista Infographics',0,'','In 2017, Roche\'s orphan drugs market share accounted for 8.2 percent of the world\'s market and is expected to decrease down to 5.2 percent by 2024.','drug','https://www.statista.com/statistics/373373/top-companies-based-on-global-orphan-drug-market-share/'),(2019,'June, 26 2018 06:50:48','','','','',0,'New NASA mission to detect plant water use from space',16,4,'Technological','June, 26 2018 00:00:00','World',4,'Information Technology','Climate Change: Vital Signs of the Planet',0,'','Over the next year, ECOSTRESS will use the space station\'s unique low Earth orbit to collect data over multiple areas of land at different times of day.','data','https://climate.nasa.gov/news/2752/new-nasa-mission-to-detect-plant-water-use-from-space/'),(2022,'June, 26 2018 04:47:28','','','','',0,'Digital twins help to reshape manufacturing',12,4,'Technological','June, 26 2018 00:00:00','',3,'Information Technology','Control Engineering ',0,'','By 2022, 85% of all IoT platforms will embrace digital twins.','internet of things','https://www.controleng.com/single-article/digital-twins-help-to-reshape-manufacturing/9ec26636b2bb4767a32ed084dab810f3.html'),(2025,'June, 26 2018 05:31:29','','','','United Kingdom',0,'Facts & Figures',16,4,'Healthcare','June, 26 2018 00:00:00','Northern Europe',4,'Healthcare','Diabetes UK',0,'','More than five million people will have diabetes in the UK by 2025.','diabetes','https://www.diabetes.org.uk/Professionals/Position-statements-reports/Statistics'),(2021,'June, 26 2018 04:14:57','','','','',0,'VMware: Decades of hybrid cloud ahead',12,4,'','June, 26 2018 00:00:00','',3,'','Computer Weekly',0,'','VMware estimates 50% of operations will be cloud-based by 2021.','','https://www.computerweekly.com/blog/StorageBuzz/VMware-Decades-of-hybrid-cloud-ahead'),(2026,'June, 26 2018 04:30:38','','','','',0,'HPE to Invest $4 Billion for Advancement of Edge Computing',16,4,'Technological','June, 26 2018 00:00:00','World',4,'Information Technology','Zacks',2017,'','The global edge computing market is expected to reach$ 20,495.24 million by 2026 from$ 7,983.61 million in 2017 at a CAGR of 11%.','computing','https://www.zacks.com/stock/news/308597/hpe-to-invest-4-billion-for-advancement-of-edge-computing'),(2038,'June, 25 2018 14:48:41','','','','',3,'Economic Benefits',60,4,'Political','June, 25 2018 00:00:00','',5,'Energy','Canada\'s Natural Gas',0,'','Taxes paid to Canada\'s federal and provincial governments from the upstream natural gas industry will total $405 billion over the next 20 years.','gas','https://www.canadasnaturalgas.ca/en/natural-gas-potential/economic-benefits'),(2050,'June, 25 2018 13:49:23','','','','',0,'EU charting wrong course on LNG in shipping, study warns',16,4,'Environmental','June, 25 2018 00:00:00','World',4,'Energy','EurActiv | EU News & policy debates, across languages',0,'','Shipping accounted for about 3% of global emissions in 2012 and will contribute between 6% and 14% by 2050 due to increased growth.','emission','https://www.euractiv.com/section/transport/news/eu-charting-wrong-course-on-lng-in-shipping-study-warns/'),(2023,'June, 26 2018 06:16:21','','','','',0,'Growing Importance of Flexible Electronics & Circuit Market 2018-2023',12,4,'Technological','June, 25 2018 00:00:00','',3,'Information Technology','SBWire',2018,'','Displays LCD and OLED are expected to hold the largest share of flexible electronics market during 2018-2023.','electronics','http://www.sbwire.com/press-releases/growing-importance-of-flexible-electronics-circuit-market-2018-2023-999095.htm'),(2048,'June, 25 2018 14:09:14','','','','',0,'ADD TITLE (ENDS WITH FORUM ON PAGE)',12,3,'Industries','June, 25 2018 00:00:00','Asia',4,'Energy','',0,'','Asia\'s demand for electricity is projected to continue to grow in the coming decades.','electricity','http://plattsinfo.platts.com/platts-insight-webinar-june28?hootPostID=75f24d0b8aa4a2db6f3484965a851772'),(2029,'June, 25 2018 09:48:40','','','','',0,'New EU biofuel rules not enough to help people or the planet',12,3,'Industries','June, 25 2018 00:00:00','',4,'Energy','Oxfam International',2020,'','The outcome of the three-way negotiations of the European Parliament, member states and the European Commission will govern the EU\'s renewable energy policy for the next decade.','policy','https://www.oxfam.org/en/pressroom/reactions/new-eu-biofuel-rules-not-enough-help-people-or-planet-0'),(2030,'June, 25 2018 04:04:32','','','','',0,'Cobalt Miners News For The Month Of June 2018',8,2,'Social','June, 24 2018 00:00:00','World',4,'Manufacturing','Seeking Alpha',0,'','The number of electric cars on the world\'s roads could reach 125 mn units by 2030.','car','https://seekingalpha.com/article/4183547-cobalt-miners-news-month-june-2018'),(2040,'June, 24 2018 13:14:27','','','','',0,'The higher education landscape is changing fast',12,4,'','June, 24 2018 00:00:00','Northern America',3,'','University World News',0,'','The North America and Western Europe region is expected to experience a further decline in its share of global education enrolments from 17.5% in 2015 to 10.7% by 2030 and 7.4% by 2040.','','http://www.universityworldnews.com/article.php?story=2018062208555853'),(2028,'June, 25 2018 04:04:33','','','','',0,'Cobalt Miners News For The Month Of June 2018',9,3,'Social','June, 24 2018 00:00:00','',3,'Manufacturing','Seeking Alpha',0,'Opportunity','Electric cars will drive a rapid ramp-up in cobalt and lithium demand for a decade.','car','https://seekingalpha.com/article/4183547-cobalt-miners-news-month-june-2018'),(2027,'June, 25 2018 04:04:32','','','','',0,'Cobalt Miners News For The Month Of June 2018',12,4,'Technological','June, 24 2018 00:00:00','',3,'Energy','Seeking Alpha',0,'Opportunity','Demand for cobalt in batteries is expected to grow at a rate of 14.5 percent per year to 2027.','battery','https://seekingalpha.com/article/4183547-cobalt-miners-news-month-june-2018'),(2039,'June, 24 2018 12:47:41','','','','',0,'The Tortoise and the Hare',15,3,'Industries','June, 24 2018 00:00:00','World',5,'Transport','',2030,'','Projections of 25 or 30 percent penetration of world-wide robotic passenger kilometers traveled by the mid 2030s will find the majority of their initial customers from the existing legions of taxi, bus and Uber users.','customer','https://www.insuranceinstitute.ca/en/cipsociety/information-services/advantage-monthly/0417-tortoise-hare'),(2060,'June, 25 2018 14:01:20','Miami','25.7876107','-80.22410608','United States of America',0,'Miami-Dade Home Values Influenced By Rising Seas (Research)',12,3,'Environmental','June, 22 2018 00:00:00','Northern America',4,'Environment','CleanTechnica',0,'','There will be 2 feet of sea level rise in the Miami area by 2060.','sea','https://cleantechnica.com/2018/06/22/miami-dade-home-values-influenced-by-rising-seas-research/'),(2035,'June, 22 2018 05:37:21','','','','',0,'The aviation industry could save $15 billion a year through connected aircraft',8,2,'Industries','June, 22 2018 00:00:00','World',4,'Aerospace & defence','TNooz',0,'Opportunity','The forecast doubling of aircraft in the skies by 2035 will create both challenges and opportunities for the global aviation industry.','aviation','https://www.tnooz.com/article/airline-connected-aircraft-lse-inmarsat/'),(2033,'June, 26 2018 05:21:50','','','','',0,'Banking and financial services jobs: mobility at an all-time high',9,3,'Economic','June, 22 2018 00:00:00','',3,'Information Technology','BankingTech.com',0,'','Artificial intelligence will replace roughly half of all financial services jobs over the next 15 years.','artificial intelligence','https://www.bankingtech.com/2018/06/banking-and-financial-services-jobs-mobility-at-an-all-time-high/'),(2065,'June, 23 2018 12:03:44','','','','United States of America',0,'3 reasons why form automation is the foundation of tomorrow\'s cities',16,4,'Social','June, 22 2018 00:00:00','Northern America',4,'','Smart Cities Dive',0,'','By 2065, foreign-born immigrants will represent 18% of the the United States population.','population','https://www.smartcitiesdive.com/news/3-reasons-why-form-automation-is-the-foundation-of-tomorrows-cities/526350/'),(2036,'June, 22 2018 05:37:20','','','','',0,'The aviation industry could save $15 billion a year through connected aircraft',9,3,'Industries','June, 22 2018 00:00:00','',3,'Aerospace & defence','TNooz',0,'Opportunity','Connected aircraft would help airlines cope with a projected increase in capacity demand with passenger numbers expected to nearly double by 2036.','passenger','https://www.tnooz.com/article/airline-connected-aircraft-lse-inmarsat/'),(2042,'June, 24 2018 12:03:13','','','','United States of America',0,'The fight over family separations proved how broken Trump\'s America really is',15,3,'Political','June, 22 2018 00:00:00','Northern America',5,'Government','Julia Belluz',0,'','Non-White racial groups will outnumber Whites in the United States by 2042 caused them.','policy','https://www.vox.com/policy-and-politics/2018/6/22/17485720/border-family-separations-trump-win'),(2045,'June, 22 2018 02:20:12','','','','United States of America',0,'Sea Level Rise Puts $117.5B at Risk from Chronic Flooding',12,4,'','June, 21 2018 00:00:00','Northern America',3,'','Insurance Journal',0,'Threat','Nearly 175 U.S. coastal communities may expect to see 10 percent or more homes at risk of chronic flooding by 2045.','','https://www.insurancejournal.com/news/national/2018/06/21/493040.htm'),(2037,'June, 22 2018 12:14:36','London','51.49999473','-0.116721844','United Kingdom',0,'London to have Europe\'s largest double-decker electric bus fleet',12,3,'Environmental','June, 20 2018 00:00:00','Northern Europe',4,'Transport','GlaEconomics',0,'','By 2037 all buses in London will be zero-emission.','emission','https://www.london.gov.uk/press-releases/mayoral/london-to-have-europes-largest-electric-bus-fleet'),(2032,'June, 19 2018 13:29:44','','','','United Kingdom',0,'\'Answers are needed\': Energy Industry feels left in the dark over Brexit',12,3,'Environmental','June, 19 2018 00:00:00','Northern Europe',4,'Environment','Business Green',2028,'','Confidence that the UK will meet its legally binding climate targets for 2028-2032 is wavering.','climate','https://www.businessgreen.com/bg/news-analysis/3034386/answers-are-needed-energy-industry-feels-left-in-the-dark-over-brexit'),(2043,'June, 25 2018 05:21:35','','','','',0,'No title could be extracted, please add manually',12,4,'Economic','June, 18 2018 00:00:00','',3,'Government','',0,'','The number of disabled UK older people receiving unpaid care is projected to rise by more than 75% over the next 25 years if the probability of receiving it remains constant.','care','https://www.pssru.ac.uk/pub/5421.pdf'),(2053,'June, 16 2018 12:51:06','','','','',0,'Why Are Poor People in America So Patriotic? One Man Went on an Odyssey to Find Out',9,3,'Economic','June, 16 2018 00:00:00','',3,'','Schwartzreport',0,'','African-Americans as a group will have zero wealth by 2053.','wealth','https://www.schwartzreport.net/why-are-poor-people-in-america-so-patriotic-one-man-went-on-an-odyssey-to-find-out/'),(2066,'June, 17 2018 03:05:07','Hong Kong','22.3049809','114.1850093','',0,'Is happiness linked to long life? Hongkongers buck the trend',12,3,'Political','June, 16 2018 00:00:00','',4,'','Kopitiam Bot',0,'','By 2066, Hong Kong\'s men are expected to live for 87.1 years and women 93.1 years.','women','https://kopitiambot.com/2018/06/16/is-happiness-linked-to-long-life-hongkongers-buck-the-trend/'),(2041,'June, 15 2018 05:10:54','','','','',0,'St Albans facing nearly 10,000 new occupants in next eight years, statistics reveal',12,4,'Social','June, 14 2018 00:00:00','',3,'','Herts Advertiser',0,'','By the year 2041 the population of St Albans will have grown to 164,900.','population','http://www.hertsad.co.uk/news/population-growth-in-st-albans-by-2026-1-5561786'),(2034,'June, 17 2018 12:30:57','','','','',0,'The numbers you need to know about the retirement crisis',9,3,'Political','June, 13 2018 00:00:00','',3,'Financial services','NOVA Next',0,'','Social Security\'s trust fund is projected to run out of money by 2034.','security','https://www.pbs.org/newshour/economy/making-sense/the-numbers-you-need-to-know-about-the-retirement-crisis'),(2056,'June, 18 2018 00:41:58','','','','',0,'Grantham says capitalism is making this one big global risk to humanity worse',8,2,'Social','June, 13 2018 00:00:00','World',4,'','MarketWatch',0,'','The global population could reach 10 billion by 2056.','population','https://www.marketwatch.com/story/grantham-says-capitalism-is-making-this-one-big-global-risk-to-humanity-worse-2018-06-13'),(2049,'June, 09 2018 13:58:57','','','','',0,'U.S. Still Lags Behind in Preparing for a Changing Arctic',6,2,'Political','June, 08 2018 00:00:00','',3,'Environment','Scientific American',2040,'','The Arctic could become a commercially attractive route by the 2040s.','arctic','https://www.scientificamerican.com/article/u-s-still-lags-behind-in-preparing-for-a-changing-arctic/?sf191389257=1');
/*!40000 ALTER TABLE `data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sign_in_data`
--

DROP TABLE IF EXISTS `sign_in_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sign_in_data` (
  `id` bigint NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sign_in_data`
--

LOCK TABLES `sign_in_data` WRITE;
/*!40000 ALTER TABLE `sign_in_data` DISABLE KEYS */;
INSERT INTO `sign_in_data` VALUES (1,'Abhi@gmail.com','abhi@1234',NULL,'Abhishek'),(2,'Abhi@gmail.com','abhi@1234',NULL,'Abhishek1');
/*!40000 ALTER TABLE `sign_in_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-03-19 18:06:11
